export default function Footer() {
  return (
    <footer className="mt-16 border-t border-gray-200 bg-gray-50">
      <div className="container grid md:grid-cols-3 gap-8 py-10">
        <div>
          <div className="font-bold text-lg mb-3">مدارس براثا الأهلية</div>
          <p className="text-sm text-gray-600">تعليم رصين ورسالة تربوية لبناء جيل مبدع في النجف الأشرف.</p>
        </div>
        <div>
          <div className="font-bold mb-3">روابط</div>
          <ul className="space-y-2 text-sm">
            <li><a href="/about">عن المدرسة</a></li>
            <li><a href="/news">الأخبار</a></li>
            <li><a href="/gallery">المعرض</a></li>
            <li><a href="/contact">تواصل معنا</a></li>
          </ul>
        </div>
        <div>
          <div className="font-bold mb-3">التواصل</div>
          <p className="text-sm text-gray-600">
            النجف الأشرف – العراق<br/>الهاتف: 0780 000 0000<br/>البريد: info@baratha.edu.iq
          </p>
        </div>
      </div>
      <div className="border-t border-gray-200 py-4 text-center text-xs text-gray-500">
        © {new Date().getFullYear()} مدارس براثا الأهلية. جميع الحقوق محفوظة.
      </div>
    </footer>
  );
}
