import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function NewsList() {
  const posts = await prisma.newsPost.findMany({
    where: { published: true, publishAt: { lte: new Date() } },
    orderBy: { publishAt: "desc" },
    take: 6
  });

  if (!posts.length) return <div className="text-center text-gray-500">لا توجد أخبار منشورة بعد.</div>;

  return (
    <div className="grid md:grid-cols-3 gap-6">
      {posts.map(p => (
        <article key={p.id} className="card p-4">
          <div className="text-xs text-gray-500">{new Date(p.publishAt).toLocaleDateString("ar-IQ")}</div>
          <h3 className="mt-2 font-bold text-lg">{p.title}</h3>
          {p.excerpt && <p className="mt-1 text-sm text-gray-600 line-clamp-3">{p.excerpt}</p>}
          <Link href={`/news/${p.slug}`} className="btn btn-outline mt-4 w-full">قراءة المزيد</Link>
        </article>
      ))}
    </div>
  );
}
