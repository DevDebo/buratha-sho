import Link from "next/link";
export default function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="container grid md:grid-cols-2 items-center gap-10 py-16">
        <div>
          <span className="inline-block mb-3 rounded-full bg-brand-100 px-3 py-1 text-xs font-semibold text-brand-700">مرحباً بكم</span>
          <h1 className="text-3xl md:text-5xl font-extrabold leading-[1.2]">مدارس براثا الأهلية – <span className="text-maroon-600">النجف الأشرف</span></h1>
          <p className="mt-4 text-gray-600">بيئة تعليمية حديثة تدعم الإبداع، الانضباط، والقيم الإنسانية. تعرّف على برامجنا ومرافقنا وإنجازات طلابنا.</p>
          <div className="mt-6 flex items-center gap-3">
            <Link href="/admissions" className="btn btn-primary">التقديم والقبول</Link>
            <Link href="/news" className="btn btn-outline">آخر الأخبار</Link>
          </div>
        </div>
        <div className="relative">
          <div className="aspect-[4/3] rounded-2xl bg-gradient-to-br from-brand-200 to-maroon-200 p-2">
            <div className="h-full w-full rounded-xl bg-white grid place-items-center text-center">
              <div>
                <div className="text-5xl mb-2">🎓</div>
                <div className="font-bold">صورة بانورامية للحرم المدرسي</div>
                <div className="text-xs text-gray-500 mt-1">استبدل هذه الصورة لاحقًا من لوحة الإدارة</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
