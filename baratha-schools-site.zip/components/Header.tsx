"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";

const nav = [
  { href: "/", label: "الرئيسية" },
  { href: "/about", label: "عن المدرسة" },
  { href: "/news", label: "الأخبار" },
  { href: "/gallery", label: "المعرض" },
  { href: "/contact", label: "تواصل معنا" },
];

export default function Header() {
  const pathname = usePathname();
  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur border-b border-gray-200">
      <div className="container flex items-center justify-between py-3">
        <Link href="/" className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-maroon-500 text-white grid place-items-center font-bold">ب</div>
          <div className="leading-tight">
            <div className="font-extrabold">مدارس براثا الأهلية</div>
            <div className="text-sm text-gray-500">النجف الأشرف</div>
          </div>
        </Link>
        <nav className="hidden md:flex items-center gap-6">
          {nav.map(n => (
            <Link key={n.href} href={n.href}
              className={clsx("text-sm font-medium hover:text-brand-700", pathname === n.href && "text-brand-700")}>
              {n.label}
            </Link>
          ))}
          <Link href="/admin" className="btn btn-outline">لوحة الإدارة</Link>
        </nav>
      </div>
    </header>
  );
}
