import Hero from "@/components/Hero";
import SectionTitle from "@/components/SectionTitle";
import NewsList from "@/components/NewsList";

export default function HomePage() {
  return (
    <>
      <Hero />
      <section className="container py-12">
        <SectionTitle title="رؤيتنا ورسالتنا" subtitle="نلتزم ببناء مجتمع تعلّمي متميّز" />
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { t: "تعليم متمركز حول الطالب", d: "برامج تراعي الفروق الفردية وتُنمّي مهارات القرن الحادي والعشرين." },
            { t: "بيئة آمنة ومحفّزة", d: "مرافق حديثة، أنشطة لا صفية، ورعاية نفسية واجتماعية." },
            { t: "شراكة مع الأسرة", d: "تواصل فعّال وشفاف يعزز نجاح الطالب وتفوقه." },
          ].map((i, idx) => (
            <div key={idx} className="card p-6">
              <div className="text-2xl">⭐</div>
              <div className="font-bold mt-2">{i.t}</div>
              <div className="text-sm text-gray-600 mt-1">{i.d}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="container py-12">
        <SectionTitle title="آخر الأخبار" />
        {/* @ts-expect-error Async Server Component */}
        <NewsList />
      </section>

      <section className="container py-12">
        <SectionTitle title="المعرض" subtitle="لقطات من نشاطاتنا ومرافقنا" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({length:8}).map((_,i)=>(
            <div key={i} className="aspect-square rounded-xl bg-gray-100 grid place-items-center">صورة {i+1}</div>
          ))}
        </div>
      </section>

      <section className="container py-12">
        <div className="card p-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <div className="font-bold text-xl">هل لديك استفسار؟</div>
            <div className="text-sm text-gray-600">تواصل معنا عبر النموذج وسنردّ عليك سريعًا.</div>
          </div>
          <a href="/contact" className="btn btn-primary">نموذج التواصل</a>
        </div>
      </section>
    </>
  );
}
