import { prisma } from "@/lib/prisma";
import { setSession } from "@/lib/auth";
import { redirect } from "next/navigation";

export async function POST(request: Request) {
  const form = await request.formData();
  const email = String(form.get("email") || "");
  const password = String(form.get("password") || "");

  if (!email || !password) return new Response("Bad Request", { status: 400 });

  const user = await prisma.user.findUnique({ where: { email } });
  const ok = user && user.password === password; // استبدلها بتجزئة لاحقًا
  if (!ok) return new Response("Unauthorized", { status: 401 });

  setSession({ id: user!.id, role: user!.role, email: user!.email });
  return redirect("/admin");
}
