import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";

export async function GET() {
  const posts = await prisma.newsPost.findMany({ orderBy: { publishAt: "desc" } });
  return Response.json(posts);
}

export async function POST(request: Request) {
  try { requireAdmin(); } catch { return new Response("Unauthorized", { status: 401 }); }

  const form = await request.formData();
  const title = String(form.get("title") || "");
  const slug = String(form.get("slug") || "");
  const excerpt = String(form.get("excerpt") || "");
  const coverUrl = String(form.get("coverUrl") || "");
  const content = String(form.get("content") || "");
  const published = form.getAll("published").length > 0;

  if (!title || !slug || !content) return Response.json({ ok: false, error: "حقول مطلوبة" }, { status: 400 });

  await prisma.newsPost.create({ data: { title, slug, excerpt, coverUrl, content, published } });
  return Response.redirect("/admin/news");
}
