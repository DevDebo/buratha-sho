import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const id = Number(params.id);
  const post = await prisma.newsPost.findUnique({ where: { id } });
  if (!post) return new Response("Not Found", { status: 404 });
  return Response.json(post);
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try { requireAdmin(); } catch { return new Response("Unauthorized", { status: 401 }); }

  const id = Number(params.id);
  const form = await request.formData();
  const method = String(form.get("_method") || "PUT").toUpperCase();

  if (method === "DELETE") {
    await prisma.newsPost.delete({ where: { id } });
    return Response.redirect("/admin/news");
  }

  const title = String(form.get("title") || "");
  const slug = String(form.get("slug") || "");
  const excerpt = String(form.get("excerpt") || "");
  const coverUrl = String(form.get("coverUrl") || "");
  const content = String(form.get("content") || "");
  const published = form.getAll("published").length > 0;

  await prisma.newsPost.update({ where: { id }, data: { title, slug, excerpt, coverUrl, content, published } });
  return Response.redirect("/admin/news");
}
