import { prisma } from "@/lib/prisma";

export async function POST(request: Request) {
  const form = await request.formData();
  const name = String(form.get("name") || "");
  const email = String(form.get("email") || "");
  const phone = String(form.get("phone") || "");
  const message = String(form.get("message") || "");

  if (!name || !email || !message) return Response.json({ ok: false, error: "حقول مطلوبة" }, { status: 400 });

  await prisma.contactMessage.create({ data: { name, email, phone, message } });
  return Response.json({ ok: true });
}
