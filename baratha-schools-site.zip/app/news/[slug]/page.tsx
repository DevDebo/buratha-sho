import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";

export default async function NewsDetails({ params }: { params: { slug: string } }) {
  const post = await prisma.newsPost.findUnique({ where: { slug: params.slug } });
  if (!post || !post.published) return notFound();

  return (
    <div className="container py-10">
      <div className="text-xs text-gray-500">{new Date(post.publishAt).toLocaleDateString("ar-IQ")}</div>
      <h1 className="text-3xl font-extrabold mt-2">{post.title}</h1>
      {post.coverUrl && <img src={post.coverUrl} alt="" className="mt-6 rounded-xl" />}
      <article className="prose prose-lg max-w-none prose-p:leading-8 mt-6" dangerouslySetInnerHTML={{ __html: post.content }} />
    </div>
  );
}
