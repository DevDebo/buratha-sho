import { prisma } from "@/lib/prisma";
import Link from "next/link";

export const revalidate = 60;

export default async function NewsPage() {
  const posts = await prisma.newsPost.findMany({
    where: { published: true, publishAt: { lte: new Date() } },
    orderBy: { publishAt: "desc" }
  });

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-extrabold mb-6">الأخبار</h1>
      <div className="grid md:grid-cols-3 gap-6">
        {posts.map(p => (
          <article key={p.id} className="card p-4">
            <div className="text-xs text-gray-500">{new Date(p.publishAt).toLocaleDateString("ar-IQ")}</div>
            <h2 className="mt-2 font-bold text-lg">{p.title}</h2>
            {p.excerpt && <p className="mt-1 text-sm text-gray-600 line-clamp-3">{p.excerpt}</p>}
            <Link href={`/news/${p.slug}`} className="btn btn-outline mt-4 w-full">قراءة المزيد</Link>
          </article>
        ))}
      </div>
    </div>
  );
}
