export default function AdmissionsPage() {
  return (
    <div className="container py-10 prose max-w-none">
      <h1 className="text-3xl font-extrabold mb-4">التقديم والقبول</h1>
      <p>سيتم فتح باب التقديم قريبًا. تابعونا للاطلاع على الشروط والمواعيد.</p>
    </div>
  );
}
