export default function AboutPage() {
  return (
    <div className="container py-10 prose prose-lg max-w-none prose-p:leading-8">
      <h1 className="text-3xl font-extrabold mb-4">عن المدرسة</h1>
      <p>تأسست مدارس براثا الأهلية في النجف الأشرف لتقديم تعليم نوعي يجمع بين الأصالة والحداثة، ويرتكز على القيم والمعرفة والابتكار.</p>
      <p>توفّر المدرسة برامج أكاديمية شاملة، هيئة تدريس مؤهلة، ومرافق متطورة تضمن تجربة تعليمية متميزة لكل طالب.</p>
    </div>
  );
}
