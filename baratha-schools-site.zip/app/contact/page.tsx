"use client";
import { useState } from "react";

export default function ContactPage() {
  const [state, setState] = useState<{ ok?: boolean; error?: string } | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const res = await fetch("/api/contact", { method: "POST", body: form });
    const data = await res.json();
    setState(data);
    if (data.ok) (e.currentTarget as HTMLFormElement).reset();
  }

  return (
    <div className="container py-10">
      <h1 className="text-3xl font-extrabold mb-6">تواصل معنا</h1>
      <form onSubmit={onSubmit} className="card p-6 grid gap-4 max-w-2xl">
        <input name="name" required placeholder="الاسم الكامل" className="border rounded-xl p-3" />
        <input type="email" name="email" required placeholder="البريد الإلكتروني" className="border rounded-xl p-3" />
        <input name="phone" placeholder="رقم الهاتف (اختياري)" className="border rounded-xl p-3" />
        <textarea name="message" required placeholder="اكتب رسالتك..." className="border rounded-xl p-3 min-h-[140px]" />
        <button className="btn btn-primary w-fit">إرسال</button>
        {state?.ok && <div className="text-green-600 text-sm">تم الإرسال بنجاح.</div>}
        {state?.error && <div className="text-red-600 text-sm">{state.error}</div>}
      </form>
    </div>
  );
}
