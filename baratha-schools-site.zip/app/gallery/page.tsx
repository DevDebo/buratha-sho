export default function GalleryPage() {
  return (
    <div className="container py-10">
      <h1 className="text-3xl font-extrabold mb-6">معرض الصور</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Array.from({length:16}).map((_,i)=>(
          <div key={i} className="aspect-square rounded-xl bg-gray-100 grid place-items-center">صورة {i+1}</div>
        ))}
      </div>
    </div>
  );
}
