import Link from "next/link";
import { getSession } from "@/lib/auth";

export default function AdminHome() {
  const session = getSession();
  return (
    <div className="grid gap-6">
      <h1 className="text-3xl font-extrabold">لوحة الإدارة</h1>
      {!session ? (
        <div className="card p-6">
          <div className="font-bold mb-2">تسجيل الدخول</div>
          <form method="POST" action="/api/auth/login" className="grid gap-3 max-w-md">
            <input name="email" required placeholder="البريد الإداري" className="border rounded-xl p-3" />
            <input type="password" name="password" required placeholder="كلمة المرور" className="border rounded-xl p-3" />
            <button className="btn btn-primary w-fit">دخول</button>
          </form>
        </div>
      ) : (
        <div className="grid gap-4">
          <div className="card p-6 grid md:grid-cols-3 gap-4">
            <Link href="/admin/news" className="btn btn-outline">إدارة الأخبار</Link>
            <form action="/api/auth/logout" method="POST"><button className="btn btn-outline">تسجيل الخروج</button></form>
          </div>
        </div>
      )}
    </div>
  );
}
