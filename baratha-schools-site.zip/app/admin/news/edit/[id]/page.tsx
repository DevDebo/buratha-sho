import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";

export default async function EditNews({ params }: { params: { id: string } }) {
  const id = Number(params.id);
  const post = await prisma.newsPost.findUnique({ where: { id } });
  if (!post) return notFound();

  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-extrabold">تعديل خبر</h1>
      <form action={`/api/news/${post.id}`} method="POST" className="card p-6 grid gap-3">
        <input name="title" defaultValue={post.title} required className="border rounded-xl p-3" />
        <input name="slug" defaultValue={post.slug} required className="border rounded-xl p-3" />
        <input name="excerpt" defaultValue={post.excerpt || ""} className="border rounded-xl p-3" />
        <input name="coverUrl" defaultValue={post.coverUrl || ""} className="border rounded-xl p-3" />
        <textarea name="content" defaultValue={post.content} required className="border rounded-xl p-3 min-h-[200px]" />
        <label className="inline-flex items-center gap-2 text-sm">
          <input type="checkbox" name="published" defaultChecked={post.published} /> منشور
        </label>
        <button className="btn btn-primary w-fit">تحديث</button>
      </form>
    </div>
  );
}
