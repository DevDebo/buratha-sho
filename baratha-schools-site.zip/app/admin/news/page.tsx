import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export default async function AdminNews() {
  const session = getSession();
  const posts = await prisma.newsPost.findMany({ orderBy: { createdAt: "desc" } });

  if (!session) return <div className="text-red-600">الرجاء تسجيل الدخول.</div>;

  return (
    <div className="grid gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-extrabold">الأخبار</h1>
        <Link href="/admin/news/new" className="btn btn-primary">خبر جديد</Link>
      </div>
      <div className="grid gap-3">
        {posts.map(p => (
          <div key={p.id} className="card p-4 flex items-center justify-between">
            <div>
              <div className="font-bold">{p.title}</div>
              <div className="text-xs text-gray-500">{p.slug}</div>
            </div>
            <div className="flex items-center gap-2">
              <Link href={`/admin/news/edit/${p.id}`} className="btn btn-outline">تعديل</Link>
              <form action={`/api/news/${p.id}`} method="POST">
                <input type="hidden" name="_method" value="DELETE" />
                <button className="btn btn-outline">حذف</button>
              </form>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
