export default function NewNews() {
  return (
    <div className="grid gap-6">
      <h1 className="text-2xl font-extrabold">إضافة خبر</h1>
      <form action="/api/news" method="POST" className="card p-6 grid gap-3">
        <input name="title" required placeholder="العنوان" className="border rounded-xl p-3" />
        <input name="slug" required placeholder="المعرف (بالإنجليزية)" className="border rounded-xl p-3" />
        <input name="excerpt" placeholder="ملخص (اختياري)" className="border rounded-xl p-3" />
        <input name="coverUrl" placeholder="رابط صورة الغلاف (اختياري)" className="border rounded-xl p-3" />
        <textarea name="content" required placeholder="محتوى HTML" className="border rounded-xl p-3 min-h-[200px]" />
        <label className="inline-flex items-center gap-2 text-sm">
          <input type="checkbox" name="published" /> نشر الآن
        </label>
        <button className="btn btn-primary w-fit">حفظ</button>
      </form>
    </div>
  );
}
